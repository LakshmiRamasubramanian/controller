import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseUrl = 'http://localhost:9312/api';
  constructor(private http: HttpClient) { }

 

  getLoginCredentials(login: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/getRole/login`, login);
  }

  

  }

