import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Login } from '../login';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login:Login =new Login();
  submitted=false;
  constructor(private dataService: LoginService) { }

  ngOnInit() {
    
  }
  
  loginCredentials(){
    this.dataService.getLoginCredentials(this.login)
    .subscribe(data => console.log(data), error => console.log(error));
     this.login=new Login();
  }
  onSubmit() {
    this.submitted=true;
    this.loginCredentials();
  }
}
