export class Login {
    id: number;
    email: string;
    password: string;
    role:string;
}
